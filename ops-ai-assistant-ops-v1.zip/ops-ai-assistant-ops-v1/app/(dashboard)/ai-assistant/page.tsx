"use client"

import AiAssistantClient from "@/components/ai/AiAssistantClient"

export default function AiAssistantPage() {
  return <AiAssistantClient scope="dashboard" />
}
