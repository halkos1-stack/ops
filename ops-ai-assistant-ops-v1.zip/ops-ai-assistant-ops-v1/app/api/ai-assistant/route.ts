import OpenAI from "openai"
import { NextRequest, NextResponse } from "next/server"
import { requireApiAppAccess } from "@/lib/route-access"
import { buildAiAssistantContext } from "@/lib/ai/build-assistant-context"
import { buildAiAssistantSystemPrompt } from "@/lib/ai/prompt"

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

type RequestBody = {
  message?: string
  scope?: "dashboard" | "property" | "task"
  propertyId?: string | null
  taskId?: string | null
}

function toTextContent(input: unknown): string {
  if (!input || typeof input !== "object") return ""

  const response = input as {
    output_text?: string
    output?: Array<{
      content?: Array<{
        type?: string
        text?: string
      }>
    }>
  }

  if (typeof response.output_text === "string" && response.output_text.trim()) {
    return response.output_text.trim()
  }

  if (!Array.isArray(response.output)) {
    return ""
  }

  const texts = response.output.flatMap((item) => {
    if (!Array.isArray(item?.content)) return []

    return item.content
      .filter((part) => part?.type === "output_text" && typeof part?.text === "string")
      .map((part) => String(part.text))
  })

  return texts.join("\n").trim()
}

export async function POST(req: NextRequest) {
  try {
    const access = await requireApiAppAccess()

    if (!access.ok) {
      return access.response
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        {
          error:
            "Δεν έχει οριστεί OPENAI_API_KEY στο περιβάλλον του συστήματος.",
        },
        { status: 500 }
      )
    }

    const body = (await req.json()) as RequestBody
    const message = String(body?.message || "").trim()
    const scope = body?.scope || "dashboard"
    const propertyId = body?.propertyId || null
    const taskId = body?.taskId || null

    if (!message) {
      return NextResponse.json(
        { error: "Το μήνυμα είναι υποχρεωτικό." },
        { status: 400 }
      )
    }

    const context = await buildAiAssistantContext({
      auth: access.auth,
      scope,
      propertyId,
      taskId,
    })

    const model = process.env.OPS_AI_MODEL || "gpt-4.1-mini"

    const response = await client.responses.create({
      model,
      temperature: 0.2,
      input: [
        {
          role: "system",
          content: [
            {
              type: "input_text",
              text: buildAiAssistantSystemPrompt(),
            },
          ],
        },
        {
          role: "user",
          content: [
            {
              type: "input_text",
              text: [
                "ΠΑΡΑΚΑΤΩ ΕΙΝΑΙ ΤΟ ΔΟΜΗΜΕΝΟ CONTEXT ΤΟΥ OPS:",
                JSON.stringify(context, null, 2),
                "",
                "ΕΡΩΤΗΣΗ ΧΡΗΣΤΗ:",
                message,
              ].join("\n"),
            },
          ],
        },
      ],
    })

    const answer = toTextContent(response)

    if (!answer) {
      return NextResponse.json(
        {
          error:
            "Ο βοηθός δεν επέστρεψε απάντηση. Δοκίμασε ξανά με πιο συγκεκριμένη ερώτηση.",
        },
        { status: 502 }
      )
    }

    return NextResponse.json({
      answer,
      meta: {
        scope,
        propertyId,
        taskId,
        generatedAt: new Date().toISOString(),
        contextSummary: context.summary,
      },
    })
  } catch (error) {
    console.error("AI assistant route error:", error)

    return NextResponse.json(
      {
        error:
          "Παρουσιάστηκε σφάλμα κατά την επικοινωνία με τον AI βοηθό.",
      },
      { status: 500 }
    )
  }
}
