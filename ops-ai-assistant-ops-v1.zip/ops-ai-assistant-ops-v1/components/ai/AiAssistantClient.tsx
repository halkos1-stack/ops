"use client"

import { useMemo, useState } from "react"
import { useAppLanguage } from "@/components/i18n/LanguageProvider"

type AiAssistantClientProps = {
  scope?: "dashboard" | "property" | "task"
  propertyId?: string | null
  taskId?: string | null
}

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
}

function getTexts(language: "el" | "en") {
  if (language === "en") {
    return {
      title: "AI assistant",
      subtitle:
        "Read-only operational assistant for summaries, pending items, alerts and context questions.",
      inputLabel: "Question",
      placeholder:
        "Example: What is pending today? Which task has active alert? Summarize the current operational picture.",
      send: "Send",
      sending: "Sending...",
      clear: "Clear conversation",
      empty:
        "Ask about open tasks, alerts, issues, supplies or the current operational picture.",
      systemNote:
        "This assistant is read-only. It does not create tasks, change statuses or update the database.",
      scopeLabel: "Context",
      scopeDashboard: "Dashboard",
      scopeProperty: "Property",
      scopeTask: "Task",
      defaultPrompt1: "What is pending today?",
      defaultPrompt2: "Which tasks have active alert?",
      defaultPrompt3: "Give me a concise operational summary.",
      errorFallback: "The assistant request failed.",
      you: "You",
      assistant: "Assistant",
    }
  }

  return {
    title: "AI βοηθός",
    subtitle:
      "Βοηθός ανάγνωσης για σύνοψη, εκκρεμότητες, alert και ερωτήσεις λειτουργικής εικόνας.",
    inputLabel: "Ερώτηση",
    placeholder:
      "Παράδειγμα: Τι εκκρεμεί σήμερα; Ποια εργασία έχει ενεργό alert; Δώσε μου σύντομη λειτουργική εικόνα.",
    send: "Αποστολή",
    sending: "Αποστολή...",
    clear: "Καθαρισμός συνομιλίας",
    empty:
      "Ρώτησε για ανοιχτές εργασίες, alert, βλάβες, αναλώσιμα ή τη συνολική επιχειρησιακή εικόνα.",
    systemNote:
      "Ο βοηθός είναι μόνο για ανάγνωση. Δεν δημιουργεί εργασίες, δεν αλλάζει καταστάσεις και δεν ενημερώνει τη βάση.",
    scopeLabel: "Πλαίσιο",
    scopeDashboard: "Πίνακας ελέγχου",
    scopeProperty: "Ακίνητο",
    scopeTask: "Εργασία",
    defaultPrompt1: "Τι εκκρεμεί σήμερα;",
    defaultPrompt2: "Ποιες εργασίες έχουν ενεργό alert;",
    defaultPrompt3: "Δώσε μου σύντομη λειτουργική εικόνα.",
    errorFallback: "Απέτυχε το αίτημα προς τον βοηθό.",
    you: "Εσύ",
    assistant: "Βοηθός",
  }
}

export default function AiAssistantClient({
  scope = "dashboard",
  propertyId = null,
  taskId = null,
}: AiAssistantClientProps) {
  const { language } = useAppLanguage()
  const texts = useMemo(() => getTexts(language), [language])

  const [question, setQuestion] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [messages, setMessages] = useState<Message[]>([])

  const scopeLabel =
    scope === "property"
      ? texts.scopeProperty
      : scope === "task"
      ? texts.scopeTask
      : texts.scopeDashboard

  async function askAssistant(customQuestion?: string) {
    const message = String(customQuestion ?? question).trim()
    if (!message || loading) return

    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: message,
    }

    setMessages((current) => [...current, userMessage])
    setQuestion("")
    setError("")
    setLoading(true)

    try {
      const response = await fetch("/api/ai-assistant", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message,
          scope,
          propertyId,
          taskId,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data?.error || texts.errorFallback)
      }

      const assistantMessage: Message = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: String(data?.answer || ""),
      }

      setMessages((current) => [...current, assistantMessage])
    } catch (err) {
      console.error("AI assistant client error:", err)
      setError(err instanceof Error ? err.message : texts.errorFallback)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            {texts.title}
          </h1>
          <p className="mt-2 max-w-3xl text-sm text-slate-500">
            {texts.subtitle}
          </p>
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
          <div className="border-b border-slate-200 px-6 py-5">
            <div className="flex flex-wrap items-center gap-3">
              <span className="inline-flex rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-600">
                {texts.scopeLabel}: {scopeLabel}
              </span>

              <span className="inline-flex rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">
                read-only
              </span>
            </div>

            <p className="mt-3 text-sm text-slate-500">{texts.systemNote}</p>
          </div>

          <div className="space-y-4 p-6">
            <label className="block text-sm font-semibold text-slate-700">
              {texts.inputLabel}
            </label>

            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              rows={5}
              placeholder={texts.placeholder}
              className="w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-slate-500"
            />

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => askAssistant()}
                disabled={loading}
                className="inline-flex items-center justify-center rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? texts.sending : texts.send}
              </button>

              <button
                type="button"
                onClick={() => {
                  setMessages([])
                  setQuestion("")
                  setError("")
                }}
                className="inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
              >
                {texts.clear}
              </button>
            </div>

            {error ? (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            ) : null}
          </div>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-500">
            Έτοιμες ερωτήσεις
          </h2>

          <div className="mt-4 flex flex-col gap-3">
            {[texts.defaultPrompt1, texts.defaultPrompt2, texts.defaultPrompt3].map(
              (prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => askAssistant(prompt)}
                  disabled={loading}
                  className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-left text-sm font-medium text-slate-700 transition hover:border-slate-300 hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {prompt}
                </button>
              )
            )}
          </div>
        </section>
      </div>

      <section className="rounded-3xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-200 px-6 py-5">
          <h2 className="text-lg font-semibold text-slate-900">Συνομιλία</h2>
        </div>

        <div className="space-y-4 p-6">
          {messages.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-8 text-center text-sm text-slate-500">
              {texts.empty}
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={
                  message.role === "user"
                    ? "rounded-2xl border border-slate-200 bg-slate-50 p-4"
                    : "rounded-2xl border border-blue-200 bg-blue-50 p-4"
                }
              >
                <div className="mb-2 text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                  {message.role === "user" ? texts.you : texts.assistant}
                </div>
                <div className="whitespace-pre-wrap text-sm leading-7 text-slate-800">
                  {message.content}
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  )
}
