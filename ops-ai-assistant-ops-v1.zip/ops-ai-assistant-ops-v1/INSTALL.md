OPS AI ΒΟΗΘΟΣ v1 — ΕΓΚΑΤΑΣΤΑΣΗ

Τι περιέχει
- app/api/ai-assistant/route.ts
- app/(dashboard)/ai-assistant/page.tsx
- components/ai/AiAssistantClient.tsx
- lib/ai/build-assistant-context.ts
- lib/ai/prompt.ts
- PATCH_DashboardSidebar.tsx

Τι κάνει
- Προσθέτει read-only AI βοηθό στο OPS.
- Απαντά για εκκρεμότητες, alert, ανοιχτές εργασίες, βλάβες και αναλώσιμα.
- Δεν γράφει στη βάση.
- Δεν αλλάζει καταστάσεις.
- Δεν δημιουργεί εργασίες.

1. Εγκατάσταση πακέτου OpenAI
npm install openai

2. Δημιούργησε τους φακέλους αν δεν υπάρχουν
- app/api/ai-assistant
- app/(dashboard)/ai-assistant
- components/ai
- lib/ai

3. Αντέγραψε τα νέα αρχεία στις σωστές θέσεις
- app/api/ai-assistant/route.ts
- app/(dashboard)/ai-assistant/page.tsx
- components/ai/AiAssistantClient.tsx
- lib/ai/build-assistant-context.ts
- lib/ai/prompt.ts

4. Αντικατάστησε το υπάρχον sidebar
- πάρε το περιεχόμενο από PATCH_DashboardSidebar.tsx
- βάλ’ το στο app/(dashboard)/DashboardSidebar.tsx

5. Βάλε μεταβλητές περιβάλλοντος στο .env
OPENAI_API_KEY=βάλε_εδώ_το_κλειδί_σου
OPS_AI_MODEL=gpt-4.1-mini

6. Τρέξε τον dev server
npm run dev

7. Άνοιξε
/dashboard/ai-assistant  <-- ΛΑΘΟΣ
/ai-assistant            <-- ΣΩΣΤΟ route μέσα στο dashboard group

Σημειώσεις
- Το route χρησιμοποιεί requireApiAppAccess(), άρα ο βοηθός είναι διαθέσιμος μόνο σε ORG_ADMIN, MANAGER και SUPER_ADMIN, όπως και το υπόλοιπο app access.
- Το context χτίζεται από τα δικά σου μοντέλα Prisma:
  Property, Task, Issue, Settings, PropertySupply, TaskChecklistRun, TaskSupplyRun, Booking, TaskAssignment.
- Αν θέλεις μετά, μπορούμε να δέσουμε τον ίδιο βοηθό και μέσα στη σελίδα ακινήτου ή στη σελίδα εργασίας με scope="property" ή scope="task".

Πρώτες ερωτήσεις που αξίζει να δοκιμάσεις
- Τι εκκρεμεί σήμερα;
- Ποιες εργασίες έχουν ενεργό alert;
- Δώσε μου σύντομη λειτουργική εικόνα.
- Ποια είναι τα πιο κρίσιμα ανοιχτά θέματα;
- Υπάρχουν αναλώσιμα σε χαμηλή στάθμη;
