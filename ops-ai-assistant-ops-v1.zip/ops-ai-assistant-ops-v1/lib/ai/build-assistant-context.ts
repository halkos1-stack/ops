import { prisma } from "@/lib/prisma"
import {
  buildTenantWhere,
  type RouteAccessContext,
} from "@/lib/route-access"

type AssistantScope = "dashboard" | "property" | "task"

type BuildContextParams = {
  auth: RouteAccessContext
  scope: AssistantScope
  propertyId?: string | null
  taskId?: string | null
}

function toIso(value: Date | string | null | undefined) {
  if (!value) return null
  const date = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(date.getTime())) return null
  return date.toISOString()
}

function normalizeTaskStatus(status?: string | null) {
  return String(status || "").toLowerCase()
}

function isOpenTask(status?: string | null) {
  return ["pending", "assigned", "accepted", "in_progress"].includes(
    normalizeTaskStatus(status)
  )
}

function isActiveAlert(task: {
  alertEnabled?: boolean | null
  alertAt?: Date | string | null
  status?: string | null
}) {
  if (!task.alertEnabled || !task.alertAt) return false
  if (!isOpenTask(task.status)) return false

  const alertDate = new Date(task.alertAt)
  if (Number.isNaN(alertDate.getTime())) return false

  return alertDate.getTime() <= Date.now()
}

function dateOnly(value: Date | string | null | undefined) {
  if (!value) return null
  const date = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(date.getTime())) return null
  return new Date(date.getFullYear(), date.getMonth(), date.getDate())
}

function isToday(value: Date | string | null | undefined) {
  const current = dateOnly(new Date())
  const target = dateOnly(value)
  if (!current || !target) return false
  return current.getTime() === target.getTime()
}

function summarizeOpenTasks(tasks: Array<{ status: string }>) {
  return tasks.reduce(
    (acc, task) => {
      const status = normalizeTaskStatus(task.status)
      if (status === "pending") acc.pending += 1
      if (status === "assigned") acc.assigned += 1
      if (status === "accepted") acc.accepted += 1
      if (status === "in_progress") acc.inProgress += 1
      return acc
    },
    {
      pending: 0,
      assigned: 0,
      accepted: 0,
      inProgress: 0,
    }
  )
}

export async function buildAiAssistantContext({
  auth,
  scope,
  propertyId,
  taskId,
}: BuildContextParams) {
  const organizationWhere = buildTenantWhere(auth)

  const [settings, properties, tasks, issues] = await Promise.all([
    prisma.settings.findFirst({
      where: organizationWhere,
      select: {
        companyName: true,
        timezone: true,
        language: true,
      },
    }),
    prisma.property.findMany({
      where: buildTenantWhere(auth, propertyId ? { id: propertyId } : {}),
      select: {
        id: true,
        code: true,
        name: true,
        address: true,
        city: true,
        region: true,
        status: true,
        defaultPartner: {
          select: {
            id: true,
            code: true,
            name: true,
            specialty: true,
            status: true,
          },
        },
        propertySupplies: {
          where: {
            isActive: true,
          },
          select: {
            id: true,
            fillLevel: true,
            lastUpdatedAt: true,
            supplyItem: {
              select: {
                id: true,
                code: true,
                name: true,
                category: true,
                unit: true,
              },
            },
          },
          orderBy: {
            lastUpdatedAt: "desc",
          },
        },
      },
      orderBy: [{ name: "asc" }],
      take: scope === "dashboard" ? 8 : 1,
    }),
    prisma.task.findMany({
      where: buildTenantWhere(auth, {
        ...(taskId ? { id: taskId } : {}),
        ...(propertyId ? { propertyId } : {}),
      }),
      select: {
        id: true,
        title: true,
        description: true,
        taskType: true,
        source: true,
        priority: true,
        status: true,
        scheduledDate: true,
        scheduledStartTime: true,
        scheduledEndTime: true,
        dueDate: true,
        completedAt: true,
        alertEnabled: true,
        alertAt: true,
        notes: true,
        resultNotes: true,
        sendCleaningChecklist: true,
        sendSuppliesChecklist: true,
        property: {
          select: {
            id: true,
            code: true,
            name: true,
            address: true,
            city: true,
            region: true,
            status: true,
          },
        },
        booking: {
          select: {
            id: true,
            sourcePlatform: true,
            guestName: true,
            checkInDate: true,
            checkOutDate: true,
            status: true,
            syncStatus: true,
          },
        },
        assignments: {
          orderBy: {
            assignedAt: "desc",
          },
          take: 3,
          select: {
            id: true,
            status: true,
            assignedAt: true,
            acceptedAt: true,
            rejectedAt: true,
            startedAt: true,
            completedAt: true,
            rejectionReason: true,
            partner: {
              select: {
                id: true,
                code: true,
                name: true,
                specialty: true,
                status: true,
              },
            },
          },
        },
        issues: {
          where: {
            status: {
              not: "resolved",
            },
          },
          select: {
            id: true,
            issueType: true,
            title: true,
            severity: true,
            status: true,
            createdAt: true,
          },
          orderBy: [{ createdAt: "desc" }],
          take: 5,
        },
        checklistRun: {
          select: {
            id: true,
            status: true,
            startedAt: true,
            completedAt: true,
            template: {
              select: {
                id: true,
                title: true,
                templateType: true,
              },
            },
            answers: {
              select: {
                id: true,
                valueBoolean: true,
                valueText: true,
                valueNumber: true,
                valueSelect: true,
                notes: true,
                issueCreated: true,
                templateItem: {
                  select: {
                    id: true,
                    label: true,
                    itemType: true,
                    category: true,
                    isRequired: true,
                    opensIssueOnFail: true,
                  },
                },
              },
            },
          },
        },
        supplyRun: {
          select: {
            id: true,
            status: true,
            startedAt: true,
            completedAt: true,
            answers: {
              select: {
                id: true,
                fillLevel: true,
                notes: true,
                propertySupply: {
                  select: {
                    id: true,
                    supplyItem: {
                      select: {
                        id: true,
                        code: true,
                        name: true,
                        category: true,
                      },
                    },
                  },
                },
              },
            },
          },
        },
        updatedAt: true,
        createdAt: true,
      },
      orderBy: [{ scheduledDate: "asc" }, { updatedAt: "desc" }],
      take: scope === "dashboard" ? 20 : 1,
    }),
    prisma.issue.findMany({
      where: buildTenantWhere(auth, {
        status: {
          not: "resolved",
        },
        ...(propertyId ? { propertyId } : {}),
        ...(taskId ? { taskId } : {}),
      }),
      select: {
        id: true,
        issueType: true,
        title: true,
        description: true,
        severity: true,
        status: true,
        reportedBy: true,
        createdAt: true,
        property: {
          select: {
            id: true,
            code: true,
            name: true,
          },
        },
        task: {
          select: {
            id: true,
            title: true,
            status: true,
          },
        },
      },
      orderBy: [{ createdAt: "desc" }],
      take: scope === "dashboard" ? 10 : 6,
    }),
  ])

  const normalizedTasks = tasks.map((task) => ({
    ...task,
    scheduledDate: toIso(task.scheduledDate),
    dueDate: toIso(task.dueDate),
    completedAt: toIso(task.completedAt),
    alertAt: toIso(task.alertAt),
    updatedAt: toIso(task.updatedAt),
    createdAt: toIso(task.createdAt),
    booking: task.booking
      ? {
          ...task.booking,
          checkInDate: toIso(task.booking.checkInDate),
          checkOutDate: toIso(task.booking.checkOutDate),
        }
      : null,
    assignments: task.assignments.map((assignment) => ({
      ...assignment,
      assignedAt: toIso(assignment.assignedAt),
      acceptedAt: toIso(assignment.acceptedAt),
      rejectedAt: toIso(assignment.rejectedAt),
      startedAt: toIso(assignment.startedAt),
      completedAt: toIso(assignment.completedAt),
    })),
    issues: task.issues.map((issue) => ({
      ...issue,
      createdAt: toIso(issue.createdAt),
    })),
    checklistRun: task.checklistRun
      ? {
          ...task.checklistRun,
          startedAt: toIso(task.checklistRun.startedAt),
          completedAt: toIso(task.checklistRun.completedAt),
        }
      : null,
    supplyRun: task.supplyRun
      ? {
          ...task.supplyRun,
          startedAt: toIso(task.supplyRun.startedAt),
          completedAt: toIso(task.supplyRun.completedAt),
        }
      : null,
  }))

  const normalizedProperties = properties.map((property) => ({
    ...property,
    propertySupplies: property.propertySupplies.map((supply) => ({
      ...supply,
      lastUpdatedAt: toIso(supply.lastUpdatedAt),
    })),
  }))

  const normalizedIssues = issues.map((issue) => ({
    ...issue,
    createdAt: toIso(issue.createdAt),
  }))

  const openTasks = normalizedTasks.filter((task) => isOpenTask(task.status))
  const alertsNow = openTasks.filter((task) => isActiveAlert(task)).length
  const tasksToday = openTasks.filter((task) => isToday(task.scheduledDate)).length
  const openIssueCount = normalizedIssues.length

  const lowSupplies = normalizedProperties.flatMap((property) =>
    property.propertySupplies
      .filter((item) => ["low", "empty", "missing"].includes(String(item.fillLevel).toLowerCase()))
      .map((item) => ({
        propertyId: property.id,
        propertyName: property.name,
        propertyCode: property.code,
        fillLevel: item.fillLevel,
        lastUpdatedAt: item.lastUpdatedAt,
        supply: item.supplyItem,
      }))
  )

  return {
    summary: {
      scope,
      organizationName: settings?.companyName || null,
      timezone: settings?.timezone || "Europe/Athens",
      language: settings?.language || "el",
      propertiesInContext: normalizedProperties.length,
      tasksInContext: normalizedTasks.length,
      openTasks: openTasks.length,
      tasksToday,
      alertsNow,
      openIssues: openIssueCount,
      lowSupplies: lowSupplies.length,
      openTaskBreakdown: summarizeOpenTasks(openTasks),
    },
    properties: normalizedProperties,
    tasks: normalizedTasks,
    issues: normalizedIssues,
    lowSupplies,
  }
}
