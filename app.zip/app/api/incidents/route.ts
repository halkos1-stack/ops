import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { requireApiAppAccess, buildTenantWhere } from "@/lib/route-access"

function toNullableString(value: unknown) {
  if (value === undefined || value === null) return null
  const text = String(value).trim()
  return text === "" ? null : text
}

function mapIssueToIncidentLike(issue: any) {
  return {
    id: issue.id,
    code: `ISS-${String(issue.id).slice(-8).toUpperCase()}`,
    propertyId: issue.propertyId,
    linkedTaskId: issue.taskId,
    type: issue.issueType,
    title: issue.title,
    description: issue.description,
    severity: issue.severity,
    status: issue.status,
    createdAt: issue.createdAt,
    updatedAt: issue.updatedAt,
    property: issue.property,
    task: issue.task,
  }
}

export async function GET(request: NextRequest) {
  try {
    const access = await requireApiAppAccess()
    if (!access.ok) return access.response

    const { auth } = access
    const { searchParams } = new URL(request.url)

    const propertyId = searchParams.get("propertyId")
    const status = searchParams.get("status")
    const type = searchParams.get("type")

    const issues = await prisma.issue.findMany({
      where: buildTenantWhere(auth, {
        ...(propertyId ? { propertyId } : {}),
        ...(status ? { status } : {}),
        ...(type ? { issueType: type } : {}),
      }),
      include: {
        property: {
          select: {
            id: true,
            code: true,
            name: true,
          },
        },
        task: {
          select: {
            id: true,
            title: true,
            status: true,
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    })

    return NextResponse.json(issues.map(mapIssueToIncidentLike))
  } catch (error) {
    console.error("GET /api/incidents error:", error)
    return NextResponse.json(
      { error: "Αποτυχία φόρτωσης συμβάντων." },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const access = await requireApiAppAccess()
    if (!access.ok) return access.response

    const { auth } = access
    const body = await request.json()

    const organizationId = auth.organizationId
    const propertyId = String(body.propertyId || "").trim()
    const issueType = String(body.type || "general").trim().toLowerCase()
    const title = toNullableString(body.title) || "Νέο συμβάν"
    const description = toNullableString(body.description)
    const severity = toNullableString(body.severity) || "medium"
    const status = toNullableString(body.status) || "open"
    const taskId = toNullableString(body.linkedTaskId)

    if (!organizationId) {
      return NextResponse.json(
        { error: "Δεν βρέθηκε organizationId." },
        { status: 400 }
      )
    }

    if (!propertyId) {
      return NextResponse.json(
        { error: "Το propertyId είναι υποχρεωτικό." },
        { status: 400 }
      )
    }

    const issue = await prisma.issue.create({
      data: {
        organizationId,
        propertyId,
        taskId,
        issueType,
        title,
        description,
        severity,
        status,
        reportedBy: auth.email,
      },
      include: {
        property: {
          select: {
            id: true,
            code: true,
            name: true,
          },
        },
        task: {
          select: {
            id: true,
            title: true,
            status: true,
          },
        },
      },
    })

    return NextResponse.json(mapIssueToIncidentLike(issue), { status: 201 })
  } catch (error) {
    console.error("POST /api/incidents error:", error)
    return NextResponse.json(
      { error: "Αποτυχία δημιουργίας συμβάντος." },
      { status: 500 }
    )
  }
}